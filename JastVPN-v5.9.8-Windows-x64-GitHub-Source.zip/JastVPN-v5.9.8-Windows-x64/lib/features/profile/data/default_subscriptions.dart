import 'dart:convert';

import 'package:hiddify/core/model/constants.dart';
import 'package:hiddify/utils/link_parsers.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DefaultSubscriptions {
  DefaultSubscriptions(this._preferences, this._import);

  static const sources = {
    'https://radarhub.top/by-source/barabama-freenodes.txt': 'RadarHub',
    'https://raw.githubusercontent.com/morpheusadam/v2ray-config/main/subs/bundles/lite.txt': 'Lite',
  };
  static const _handledKey = 'jastvpn_handled_default_subscriptions';
  static const _removedKey = 'jastvpn_removed_default_subscriptions';

  final SharedPreferences _preferences;
  final Future<bool> Function(String url, String name) _import;
  Future<void>? _pending;

  Future<void> seed() => _pending ??= _seed().whenComplete(() {
    _pending = null;
  });

  Future<void> _seed() async {
    for (final entry in sources.entries) {
      try {
        final handled = _preferences.getStringList(_handledKey) ?? [];
        if (handled.contains(entry.key) || (_preferences.getStringList(_removedKey) ?? []).contains(entry.key)) {
          continue;
        }
        if (await _import(entry.key, '${Constants.appName} · ${entry.value}')) {
          await _preferences.setStringList(_handledKey, [...handled, entry.key]);
        }
      } on Exception {
        // An unavailable feed must not block the other source or overwrite its existing profile.
      }
    }
  }

  static Future<void> rememberRemoved(SharedPreferences preferences, String? url) async {
    if (url == null || !sources.containsKey(url)) return;
    final removed = preferences.getStringList(_removedKey)?.toSet() ?? <String>{};
    if (removed.add(url)) await preferences.setStringList(_removedKey, removed.toList());
  }
}

/// Compare connection parameters, ignoring the display name and query order.
/// Structured configs and metadata still pass to the existing core unchanged.
String deduplicateSubscription(String content) {
  final trimmed = content.trim();
  final decoded = trimmed.contains('://') ? trimmed : safeDecodeBase64(trimmed.replaceAll(RegExp(r'\s'), ''));
  final lines = decoded.split('\n');
  final seen = <String>{};
  var removed = false;
  final unique = <String>[];
  for (final line in lines) {
    final key = _connectionKey(line.trim());
    if (key == null || seen.add(key)) {
      unique.add(line);
    } else {
      removed = true;
    }
  }
  return removed ? unique.join('\n') : content;
}

const _shareSchemes = {
  'vless',
  'vmess',
  'trojan',
  'ss',
  'hysteria',
  'hysteria2',
  'hy2',
  'tuic',
  'anytls',
  'socks',
  'socks5',
};

String? _connectionKey(String link) {
  final uri = Uri.tryParse(link);
  if (uri == null || !uri.hasAuthority || !_shareSchemes.contains(uri.scheme)) return null;
  if (uri.scheme == 'vmess' && !uri.hasPort && uri.userInfo.isEmpty) {
    try {
      final json = jsonDecode(utf8.decode(base64Decode(base64.normalize(link.substring(8).split('#').first))));
      if (json case final Map<String, dynamic> fields) {
        return 'vmess:${jsonEncode(_canonicalJson(Map.of(fields)..remove("ps")))}';
      }
    } on FormatException {
      return null;
    }
  }
  final scheme = uri.scheme == 'hy2' ? 'hysteria2' : uri.scheme;
  final parameters = uri.queryParametersAll;
  return jsonEncode([
    scheme,
    uri.host.toLowerCase(),
    uri.port,
    uri.userInfo,
    uri.path,
    for (final key in parameters.keys.toList()..sort()) [key, parameters[key]],
  ]);
}

Object? _canonicalJson(Object? value) => switch (value) {
  final Map<String, dynamic> map => {for (final key in map.keys.toList()..sort()) key: _canonicalJson(map[key])},
  final List<dynamic> list => list.map(_canonicalJson).toList(),
  _ => value,
};
