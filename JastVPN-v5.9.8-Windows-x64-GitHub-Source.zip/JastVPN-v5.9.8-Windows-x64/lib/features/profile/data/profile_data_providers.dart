import 'dart:async';

import 'package:dio/dio.dart';
import 'package:hiddify/core/db/provider/db_providers.dart';
import 'package:hiddify/core/directories/directories_provider.dart';
import 'package:hiddify/core/http_client/http_client_provider.dart';
import 'package:hiddify/core/preferences/preferences_provider.dart';
import 'package:hiddify/features/profile/data/default_subscriptions.dart';
import 'package:hiddify/features/profile/data/profile_data_source.dart';
import 'package:hiddify/features/profile/data/profile_parser.dart';
import 'package:hiddify/features/profile/data/profile_path_resolver.dart';
import 'package:hiddify/features/profile/data/profile_repository.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/settings/data/config_option_data_providers.dart';
import 'package:hiddify/hiddifycore/hiddify_core_service_provider.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'profile_data_providers.g.dart';

@Riverpod(keepAlive: true)
Future<ProfileRepository> profileRepository(Ref ref) async {
  final repo = ProfileRepositoryImpl(
    profileDataSource: ref.watch(profileDataSourceProvider),
    profilePathResolver: ref.watch(profilePathResolverProvider),
    singbox: ref.watch(hiddifyCoreServiceProvider),
    configOptionRepository: ref.watch(configOptionRepositoryProvider),
    profileParser: ref.watch(profileParserProvider),
  );
  await repo.init().getOrElse((l) => throw l).run();
  return repo;
}

@Riverpod(keepAlive: true)
ProfileDataSource profileDataSource(Ref ref) {
  return ProfileDao(ref.watch(dbProvider));
}

@Riverpod(keepAlive: true)
ProfilePathResolver profilePathResolver(Ref ref) {
  return ProfilePathResolver(ref.watch(appDirectoriesProvider).requireValue.workingDir);
}

@Riverpod(keepAlive: true)
ProfileParser profileParser(Ref ref) {
  return ProfileParser(httpClient: ref.watch(httpClientProvider));
}

final defaultSubscriptionsProvider = Provider<DefaultSubscriptions>((ref) {
  final preferences = ref.watch(sharedPreferencesProvider).requireValue;
  final repository = ref.watch(profileRepositoryProvider).requireValue;
  final dataSource = ref.watch(profileDataSourceProvider);
  return DefaultSubscriptions(preferences, (url, name) async {
    if (await dataSource.getByUrl(url) != null) return true;
    final cancelToken = CancelToken();
    final timeout = Timer(const Duration(seconds: 20), cancelToken.cancel);
    try {
      final result = await repository
          .upsertRemote(
            url,
            userOverride: UserOverride(name: name, updateInterval: 6),
            cancelToken: cancelToken,
          )
          .run();
      return result.isRight();
    } finally {
      timeout.cancel();
    }
  });
});
