import 'dart:io';

import 'package:flutter/services.dart';
import 'package:hiddify/core/preferences/general_preferences.dart';
import 'package:hiddify/core/widget/ambient_motion.dart';
import 'package:hiddify/features/connection/notifier/connection_notifier.dart';
import 'package:hiddify/hiddifycore/hiddify_core_service_provider.dart';
import 'package:hiddify/utils/utils.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:screen_retriever/screen_retriever.dart';
import 'package:tray_manager/tray_manager.dart';
import 'package:window_manager/window_manager.dart';

part 'window_notifier.g.dart';

const minimumWindowSize = Size(368, 568);
const defaultWindowSize = Size(868, 668);

@Riverpod(keepAlive: true)
class WindowNotifier extends _$WindowNotifier with AppLogger {
  /// A silent start leaves the window hidden, so the saved maximized state waits for [show].
  bool _maximizeOnShow = false;

  @override
  Future<void> build() async {
    if (!PlatformUtils.isDesktop) return;

    // if (Platform.isWindows) {
    //   loggy.debug("ensuring single instance");
    //   await WindowsSingleInstance.ensureSingleInstance([], "Hiddify");
    // }

    await windowManager.ensureInitialized();
    if (Platform.isWindows) {
      // Windows ends the session, or a setup closes the app to update it (hiddify-app#2573): the
      // window is often hidden in the tray, and the setup waits for the app to exit.
      const MethodChannel('com.hiddify.app/session').setMethodCallHandler((call) async {
        if (call.method != 'endSession') return;
        loggy.info("windows ends the session, exiting");
        await exit();
      });
    }
    await initWindowState();
  }

  Future<void> saveWindowState() async {
    if (await windowManager.isMaximized()) {
      await ref.read(Preferences.windowMaximized.notifier).update(true);
    } else {
      final size = await windowManager.getSize();
      final position = await windowManager.getPosition();

      await ref.read(Preferences.windowMaximized.notifier).update(false);
      await ref.read(Preferences.windowSize.notifier).update(size);
      await ref.read(Preferences.windowPosition.notifier).update(position);
    }
  }

  Future<void> initWindowState() async {
    final isMaximized = ref.read(Preferences.windowMaximized);
    loggy.debug("window state. maximized: $isMaximized");
    final size = ref.read(Preferences.windowSize);
    loggy.debug("window state. size: $size");
    final position = ref.read(Preferences.windowPosition);
    final isWindowVisible = position != null && await checkWindowVisivility(position, size);
    loggy.debug("window state. position: ${isWindowVisible ? position : "centered"}");
    final silentStart = ref.read(Preferences.silentStart);
    loggy.debug("window state. silent start: ${silentStart ? "Enabled" : "Disabled"}");

    await windowManager.waitUntilReadyToShow(
      WindowOptions(size: size, center: !isWindowVisible, minimumSize: minimumWindowSize),
    );
    if (isWindowVisible) {
      await windowManager.setPosition(position);
      loggy.debug("restoring window to position: $position");
    } else {
      loggy.debug("no previous position found, centering window");
    }
    if (isMaximized) {
      if (silentStart) {
        // Maximizing shows a hidden window on Windows, which would undo the silent start.
        _maximizeOnShow = true;
        loggy.debug("window maximized once it is shown");
      } else {
        await windowManager.maximize();
        loggy.debug("restoring window to maximized state");
      }
    }
    if (!silentStart) {
      await ref.read(windowNotifierProvider.notifier).show(focus: false);
      loggy.debug("showing app window on start");
    } else {
      seeWindow(hidden: true);
      loggy.debug("silent start, remain hidden accessible via tray");
    }
  }

  Future<bool> checkWindowVisivility(Offset windowPos, Size windowSize, {double tolerance = 10.0}) async {
    final Rect windowRect = windowPos & windowSize;

    final displays = await screenRetriever.getAllDisplays();

    for (final display in displays) {
      if (display.visiblePosition == null || display.visibleSize == null) {
        continue;
      }
      final Rect monitorRect = display.visiblePosition! & display.visibleSize!;
      if (windowRect.left >= (monitorRect.left - tolerance) &&
          windowRect.top >= (monitorRect.top - tolerance) &&
          windowRect.right <= (monitorRect.right + tolerance) &&
          windowRect.bottom <= (monitorRect.bottom + tolerance)) {
        return true;
      }
    }
    return false;
  }

  Future<void> show({bool focus = true}) async {
    seeWindow(hidden: false);
    await windowManager.show();
    if (_maximizeOnShow) {
      _maximizeOnShow = false;
      await windowManager.maximize();
    }
    if (focus) await windowManager.focus();
    if (Platform.isMacOS) {
      await windowManager.setSkipTaskbar(false);
    }
  }

  Future<void> hide() async {
    // nothing moves from now on, without waiting for the engine to report the window hidden
    seeWindow(hidden: true);
    await windowManager.hide();
    if (Platform.isMacOS) {
      await windowManager.setSkipTaskbar(true);
    }
  }

  Future<void> showOrHide() async {
    if (await windowManager.isVisible()) {
      await hide();
    } else {
      await show();
    }
  }

  Future<void> exit() async {
    // A system VPN belongs to macOS and remains connected after the UI quits.
    // The Disconnect action still explicitly stops it and disables on demand.
    if (!ref.read(hiddifyCoreServiceProvider).core.persistsAfterAppExit) {
      await ref
          .read(connectionNotifierProvider.notifier)
          .abortConnection()
          .timeout(const Duration(seconds: 2))
          .catchError((e) {
            loggy.warning("error aborting connection on quit", e);
          });
    }
    // The core runs in a process of its own: it stops now, restoring the system proxy, instead of
    // when it notices the app is gone (an AppImage's files vanish as soon as the app exits).
    await ref.read(hiddifyCoreServiceProvider).core.shutdown().catchError((Object e) {
      loggy.warning("error stopping the core on quit", e);
    });
    await trayManager.destroy();
    await windowManager.destroy();
  }
}
