import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hiddify/core/localization/translations.dart';
import 'package:hiddify/core/model/constants.dart';
import 'package:hiddify/features/connection/model/connection_status.dart';
import 'package:hiddify/features/connection/notifier/connection_notifier.dart';
import 'package:hiddify/features/proxy/active/active_proxy_notifier.dart';
import 'package:hiddify/features/settings/data/config_option_repository.dart';
import 'package:hiddify/features/system_tray/desktop_status_badge.dart';
import 'package:hiddify/features/window/notifier/window_notifier.dart';
import 'package:hiddify/gen/assets.gen.dart';
import 'package:hiddify/singbox/model/singbox_config_enum.dart';
import 'package:hiddify/utils/utils.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:tray_manager/tray_manager.dart';
import 'package:window_manager/window_manager.dart';

part 'system_tray_notifier.g.dart';

@Riverpod(keepAlive: true)
class SystemTrayNotifier extends _$SystemTrayNotifier with TrayListener, AppLogger {
  bool listenerAdded = false;
  @override
  Future<void> build() async {
    assert(PlatformUtils.isDesktop);
    if (!listenerAdded) {
      trayManager.addListener(this);
      listenerAdded = true;
    }
    await _initializeTray();
  }

  // What the tray shows now, or was last asked to show. The active proxy changes many times a
  // minute while proxies are tested, and each run of [_initializeTray] used to load the icon
  // again, encode it and hand it, the tooltip and a new menu to the system, though nothing of
  // them had changed. Each is noted before its call, so a run that starts while the call is on
  // its way does not repeat it, and forgotten when the call fails, so the next run tries again.
  DesktopBadgeStatus? _shownBadge;
  (String, bool)? _shownIcon;
  String? _shownTooltip;
  String? _shownMenu;
  bool _badgeLabelCleared = false;

  Future<void> _initializeTray() async {
    // Watch AsyncValues directly (not .future): after disconnect the proxy
    // provider used to error while still holding a previous delay, and awaiting
    // .future could leave the tray on the old green/error mark.
    final connection = ref.watch(connectionNotifierProvider).valueOrNull ?? const ConnectionStatus.disconnected();
    // the ping alone, which the tooltip shows: the rest of the active proxy is not the tray's
    final urlTestDelay = connection is Connected
        ? ref.watch(activeProxyNotifierProvider.select((proxy) => proxy.valueOrNull?.urlTestDelay ?? 0))
        : 0;
    // Dock/taskbar/tray mark: none when disconnected, error while the core waits for a ping,
    // green once the core reports connected.
    final badge = switch (connection) {
      Connected() => DesktopBadgeStatus.ok,
      Waiting() || NoAvailableProxies() => DesktopBadgeStatus.error,
      _ => DesktopBadgeStatus.none,
    };
    // Update the Dock/taskbar mark before any other await so a cancelled rebuild
    // (or a slow tray API) cannot leave a green dot after disconnect.
    if (badge != _shownBadge) {
      _shownBadge = badge;
      await DesktopStatusBadge.setStatus(badge);
    }

    final t = await ref.watch(translationsProvider.future);
    final serviceMode = ref.watch(ConfigOptions.serviceMode);

    final icon = (
      _trayIconPath(connection, badge: badge),
      // Template mode on macOS forces monochrome menu-bar tint and strips color.
      // Only use it for the idle (disconnected) icon.
      PlatformUtils.isMacOS && badge == DesktopBadgeStatus.none && connection is Disconnected,
    );
    if (icon != _shownIcon) {
      _shownIcon = icon;
      try {
        await trayManager.setIcon(icon.$1, isTemplate: icon.$2);
      } catch (_) {
        _shownIcon = null;
        rethrow;
      }
    }
    if (!PlatformUtils.isLinux) {
      if (Platform.isMacOS && !_badgeLabelCleared) {
        _badgeLabelCleared = true;
        windowManager.setBadgeLabel('');
      }
      final tooltip = _trayTooltip(connection, urlTestDelay, t, badge: badge);
      if (tooltip != _shownTooltip) {
        _shownTooltip = tooltip;
        try {
          await trayManager.setToolTip(tooltip);
        } catch (_) {
          _shownTooltip = null;
          rethrow;
        }
      }
    }
    final menu = _trayMenu(connection, serviceMode, t);
    // what the menu says, which is all that tells two menus apart
    final menuText = _menuText(menu);
    if (menuText != _shownMenu) {
      _shownMenu = menuText;
      try {
        await trayManager.setContextMenu(menu);
      } catch (_) {
        _shownMenu = null;
        rethrow;
      }
    }
  }

  /// The labels, checks and disabled states of [menu], submenus too, as one string.
  static String _menuText(Menu menu) => (menu.items ?? const <MenuItem>[])
      .map((item) {
        final submenu = item.submenu == null ? '' : '{${_menuText(item.submenu!)}}';
        return '${item.type}|${item.key}|${item.label}|${item.checked}|${item.disabled}$submenu';
      })
      .join(';');

  Menu _trayMenu(ConnectionStatus connection, ServiceMode serviceMode, Translations t) => Menu(
    items: [
      if (PlatformUtils.isLinux) ...[MenuItem(key: 'dashboard', label: t.common.dashboard), MenuItem.separator()],
      MenuItem(
        key: 'connection',
        label: switch (connection) {
          Disconnected() => t.connection.connect,
          Connecting() => t.connection.connecting,
          Connected() || Waiting() || NoAvailableProxies() => t.connection.disconnect,
          Disconnecting() => t.connection.disconnecting,
          HotReloading() => t.connection.hotReloading,
        },
        disabled: connection.isSwitching,
      ),
      MenuItem.submenu(
        label: t.pages.settings.inbound.serviceMode,
        icon: Assets.images.trayIconIco,
        submenu: Menu(
          items: [
            ...ServiceMode.choices.map(
              (e) => MenuItem.checkbox(checked: e == serviceMode, key: e.name, label: e.present(t)),
            ),
          ],
        ),
      ),
      MenuItem.separator(),
      MenuItem(key: 'quit', label: t.common.quit),
    ],
  );

  /// Status-bar / system-tray icon for all desktops (macOS, Windows, Linux).
  ///
  /// Green Hi when [badge] is ok; red Hi when error (connected, no ping);
  /// idle theme icon when disconnected; red transitional while switching.
  String _trayIconPath(ConnectionStatus status, {required DesktopBadgeStatus badge}) {
    final isDarkMode = WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
    const images = Assets.images;
    final isWindows = PlatformUtils.isWindows;
    switch (badge) {
      case DesktopBadgeStatus.ok:
        return isWindows ? images.trayIconConnectedIco : images.trayIconConnectedPng.path;
      case DesktopBadgeStatus.error:
        return isWindows ? images.trayIconDisconnectedIco : images.trayIconDisconnectedPng.path;
      case DesktopBadgeStatus.none:
        break;
    }
    switch (status) {
      case Connecting():
      case Waiting():
      case NoAvailableProxies():
      case Disconnecting():
        return isWindows ? images.trayIconDisconnectedIco : images.trayIconDisconnectedPng.path;
      case Connected():
      case HotReloading():
      case Disconnected():
        // Light bar → darker glyph; dark bar → lighter glyph.
        return isWindows
            ? isDarkMode
                  ? images.trayIconIco
                  : images.trayIconDarkIco
            : isDarkMode
            ? images.trayIconPng.path
            : images.trayIconDarkPng.path;
    }
  }

  String _trayTooltip(
    ConnectionStatus connection,
    int urlTestDelay,
    Translations t, {
    required DesktopBadgeStatus badge,
  }) {
    final r = "${Constants.appName} - ${connection.present(t)}";
    if (badge == DesktopBadgeStatus.ok) {
      return '$r : ${urlTestDelay}ms';
    }
    return r;
  }

  @override
  Future<void> onTrayMenuItemClick(MenuItem menuItem) async {
    // if (menuItem.key == 'dashboard') {
    //   await ref.read(windowNotifierProvider.notifier).open();
    // }
    if (menuItem.key == 'dashboard') {
      await ref.read(windowNotifierProvider.notifier).show();
    } else if (menuItem.key == 'connection') {
      await ref.read(connectionNotifierProvider.notifier).toggleConnection();
    } else if (menuItem.key == 'quit') {
      await ref.read(windowNotifierProvider.notifier).exit();
    } else {
      final newMode = ServiceMode.values.byName(menuItem.key!);
      loggy.debug("switching service mode: [$newMode]");
      await ref.read(ConfigOptions.serviceMode.notifier).update(newMode);
    }
  }

  @override
  Future<void> onTrayIconMouseDown() async {
    // if (Platform.isMacOS) {
    //   await trayManager.popUpContextMenu();
    // } else {
    //   await ref.read(windowNotifierProvider.notifier).hideOrShow();
    // }
    await ref.read(windowNotifierProvider.notifier).showOrHide();
  }

  @override
  Future<void> onTrayIconRightMouseDown() async {
    // Windows sends keys to a tray menu only when its owner is the foreground window. Without
    // that, a menu opened from the keyboard (Win+B, then Shift+F10 or the menu key) left the
    // focus on the taskbar: the arrow keys moved between tray icons and closed the menu, and a
    // click elsewhere did not close it (#2570). tray_manager 0.5 activates the window only when
    // asked; later versions always do, but need a newer Flutter.
    // ignore: deprecated_member_use
    await trayManager.popUpContextMenu(bringAppToFront: PlatformUtils.isWindows);
  }
}

// @Riverpod(keepAlive: true)
// class SystemTrayNotifier extends _$SystemTrayNotifier with AppLogger {
//   @override
//   Future<void> build() async {
//     if (!PlatformUtils.isDesktop) return;

//     final activeProxy = await ref.watch(activeProxyNotifierProvider.future);
//     final delay = activeProxy.urlTestDelay;
//     final newConnectionStatus = delay > 0 && delay < 65000;
//     ConnectionStatus connection;
//     try {
//       connection = await ref.watch(connectionNotifierProvider.future);
//     } catch (e) {
//       loggy.warning("error getting connection status", e);
//       connection = const ConnectionStatus.disconnected();
//     }

//     final t = await ref.watch(translationsProvider.future);

//     var tooltip = Constants.appName;
//     final serviceMode = ref.watch(ConfigOptions.serviceMode);
//     if (connection is Disconnected) {
//       setIcon(connection);
//     } else if (newConnectionStatus) {
//       setIcon(const Connected());
//       tooltip = "$tooltip - ${connection.present(t)}";
//       if (newConnectionStatus) {
//         tooltip = "$tooltip : ${delay}ms";
//       } else {
//         tooltip = "$tooltip : -";
//       }
//       // else if (delay>1000)
//       //   SystemTrayNotifier.setIcon(timeout ? Disconnecting() : Connecting());
//     } else {
//       setIcon(const Disconnecting());
//       tooltip = "$tooltip - ${connection.present(t)}";
//     }
//     if (Platform.isMacOS) {
//       windowManager.setBadgeLabel("${delay}ms");
//     }
//     if (!Platform.isLinux) await trayManager.setToolTip(tooltip);

//     // final destinations = <(String label, String location)>[
//     //   (t.home.pageTitle, const HomeRoute().location),
//     //   (t.proxies.pageTitle, const ProfilesOverviewRoute().location),
//     //   (t.logs.title, const LogsOverviewRoute().location),
//     //   // (t.settings.pageTitle, const SettingsRoute().location),
//     //   (t.about.pageTitle, const AboutRoute().location),
//     // ];

//     // loggy.debug('updating system tray');

//     final menu = Menu(
//       items: [
//         MenuItem(
//           label: t.tray.dashboard,
//           onClick: (_) async {
//             await ref.read(windowNotifierProvider.notifier).open();
//           },
//         ),
//         MenuItem.separator(),
//         MenuItem.checkbox(
//           label: switch (connection) {
//             Disconnected() => t.tray.status.connect,
//             Connecting() => t.tray.status.connecting,
//             Connected() => t.tray.status.disconnect,
//             Disconnecting() => t.tray.status.disconnecting,
//           },
//           // checked: connection.isConnected,
//           checked: false,
//           disabled: connection.isSwitching,
//           onClick: (_) async {
//            await ref.read(connectionNotifierProvider.notifier).toggleConnection();
//          },
//        ),
//         MenuItem.separator(),
//         MenuItem(
//           label: t.config.serviceMode,
//           icon: Assets.images.trayIconIco,
//           disabled: true,
//         ),

//         ...ServiceMode.values.map(
//           (e) => MenuItem.checkbox(
//             checked: e == serviceMode,
//             key: e.name,
//             label: e.present(t),
//             onClick: (menuItem) async {
//               final newMode = ServiceMode.values.byName(menuItem.key!);
//               loggy.debug("switching service mode: [$newMode]");
//               await ref.read(ConfigOptions.serviceMode.notifier).update(newMode);
//             },
//           ),
//         ),

//         // MenuItem.submenu(
//         //   label: t.tray.open,
//         //   submenu: Menu(
//         //     items: [
//         //       ...destinations.map(
//         //         (e) => MenuItem(
//         //           label: e.$1,
//         //           onClick: (_) async {
//         //             await ref.read(windowNotifierProvider.notifier).open();
//         //             ref.read(routerProvider).go(e.$2);
//         //           },
//         //         ),
//         //       ),
//         //     ],
//         //   ),
//         // ),
//         MenuItem.separator(),
//         MenuItem(
//           label: t.tray.quit,
//           onClick: (_) async {
//             return ref.read(windowNotifierProvider.notifier).quit();
//           },
//         ),
//       ],
//     );

//     await trayManager.setContextMenu(menu);
//   }

//   static void setIcon(ConnectionStatus status) {
//     if (!PlatformUtils.isDesktop) return;
//     trayManager
//         .setIcon(
//           _trayIconPath(status),
//           isTemplate: Platform.isMacOS,
//         )
//         .asStream();
//   }

//   static String _trayIconPath(ConnectionStatus status) {
//     if (Platform.isWindows) {
//       final Brightness brightness = WidgetsBinding.instance.platformDispatcher.platformBrightness;
//       final isDarkMode = brightness == Brightness.dark;
//       switch (status) {
//         case Connected():
//           return Assets.images.trayIconConnectedIco;
//         case Connecting():
//           return Assets.images.trayIconDisconnectedIco;
//         case Disconnecting():
//           return Assets.images.trayIconDisconnectedIco;
//         case Disconnected():
//           if (isDarkMode) {
//             return Assets.images.trayIconIco;
//           } else {
//             return Assets.images.trayIconDarkIco;
//           }
//       }
//     }
//     // const isDarkMode = false;
//     switch (status) {
//       case Connected():
//         return Assets.images.trayIconConnectedPng.path;
//       case Connecting():
//         return Assets.images.trayIconDisconnectedPng.path;
//       case Disconnecting():
//         return Assets.images.trayIconDisconnectedPng.path;
//       case Disconnected():
//         // if (isDarkMode) {
//         //   return Assets.images.trayIconDarkPng.path;
//         // } else {
//         //   return Assets.images.trayIconPng.path;
//         // }
//         return Assets.images.trayIconPng.path;
//     }
//     // return Assets.images.trayIconPng.path;
//   }
// }
