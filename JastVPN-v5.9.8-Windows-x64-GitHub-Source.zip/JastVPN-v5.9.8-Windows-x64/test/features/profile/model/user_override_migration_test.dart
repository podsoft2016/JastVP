import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';

void main() {
  /// Build a stored v1 record (the shape written before extraSecurity/fragment).
  String v1(Map<String, Object?> fields) => jsonEncode({'version': 1, ...fields});

  group("UserOverride v1 -> v2 migration", () {
    test("enableWarp becomes extraSecurity: warp", () {
      final o = UserOverride.fromStr(v1({'enableWarp': true}))!;
      expect(o.extraSecurity, equals('warp'));
      expect(o.version, equals(latestUserOverrideVersion));
    });

    test("enablePsiphon becomes extraSecurity: psiphon", () {
      expect(UserOverride.fromStr(v1({'enablePsiphon': true}))!.extraSecurity, equals('psiphon'));
    });

    test("both enabled: psiphon wins (matches v1 behaviour)", () {
      final o = UserOverride.fromStr(v1({'enableWarp': true, 'enablePsiphon': true}))!;
      expect(o.extraSecurity, equals('psiphon'));
    });

    test("enableFragment is untouched — it keeps its own meaning", () {
      final o = UserOverride.fromStr(v1({'enableFragment': true}))!;
      expect(o.enableFragment, isTrue);
      expect(o.extraSecurity, isNull);
    });

    test("false flags stay unset", () {
      final o = UserOverride.fromStr(
        v1({'enableWarp': false, 'enablePsiphon': false, 'enableFragment': false}),
      )!;
      expect(o.extraSecurity, isNull);
      expect(o.enableFragment, isFalse);
    });

    test("other v1 fields survive", () {
      final o = UserOverride.fromStr(
        v1({'name': 'My Profile', 'updateInterval': 12, 'isAutoUpdateDisable': true, 'enableWarp': true}),
      )!;
      expect(o.name, equals('My Profile'));
      expect(o.updateInterval, equals(12));
      expect(o.isAutoUpdateDisable, isTrue);
      expect(o.extraSecurity, equals('warp'));
    });

    test("a record with no version is treated as v1", () {
      final o = UserOverride.fromStr(jsonEncode({'enableWarp': true}))!;
      expect(o.extraSecurity, equals('warp'));
      expect(o.version, equals(latestUserOverrideVersion));
    });

    test("empty v1 record migrates without error", () {
      final o = UserOverride.fromStr(v1({}))!;
      expect(o.extraSecurity, isNull);
      expect(o.enableFragment, isNull);
    });
  });

  group("UserOverride v2 round-trip", () {
    test("v2 values survive toStr -> fromStr", () {
      const original = UserOverride(name: 'p', updateInterval: 6, extraSecurity: 'warp', enableFragment: true);
      final restored = UserOverride.fromStr(original.toStr())!;
      expect(restored.extraSecurity, equals('warp'));
      expect(restored.enableFragment, isTrue);
      expect(restored.name, equals('p'));
      expect(restored.updateInterval, equals(6));
      expect(restored.adminPreference, equals(UserAdminPreference.unset));
    });

    test("a v2 record is not migrated again", () {
      const original = UserOverride(extraSecurity: 'psiphon');
      final restored = UserOverride.fromStr(original.toStr())!;
      expect(restored.extraSecurity, equals('psiphon'));
      expect(restored.version, equals(latestUserOverrideVersion));
    });

    test("null input returns null", () {
      expect(UserOverride.fromStr(null), isNull);
    });
  });

  group("UserOverride v2 -> v3 migration", () {
    test("missing adminPreference defaults to unset", () {
      final o = UserOverride.fromStr(
        jsonEncode({'version': 2, 'extraSecurity': 'warp'}),
      )!;
      expect(o.adminPreference, equals(UserAdminPreference.unset));
      expect(o.extraSecurity, equals('warp'));
      expect(o.version, equals(latestUserOverrideVersion));
    });

    test("stored preferAdmin survives", () {
      final o = UserOverride.fromStr(
        jsonEncode({'version': 3, 'adminPreference': 'preferAdmin'}),
      )!;
      expect(o.adminPreference, equals(UserAdminPreference.preferAdmin));
    });

    test("v1 record also gets unset adminPreference", () {
      final o = UserOverride.fromStr(v1({'enableWarp': true}))!;
      expect(o.adminPreference, equals(UserAdminPreference.unset));
      expect(o.version, equals(latestUserOverrideVersion));
    });
  });
}
