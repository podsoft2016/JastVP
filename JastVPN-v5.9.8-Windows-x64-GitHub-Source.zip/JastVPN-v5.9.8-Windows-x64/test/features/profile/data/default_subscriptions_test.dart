import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:hiddify/features/profile/data/default_subscriptions.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('imports both defaults and remembers the successful imports', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final urls = <String>[];
    final defaults = DefaultSubscriptions(prefs, (url, _) async {
      urls.add(url);
      return true;
    });
    await defaults.seed();
    await defaults.seed();
    expect(urls, DefaultSubscriptions.sources.keys.toList());
  });

  test('one failure leaves the other working and missing sources retry', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final urls = <String>[];
    final first = DefaultSubscriptions.sources.keys.first;
    final defaults = DefaultSubscriptions(prefs, (url, _) async {
      urls.add(url);
      if (urls.length == 1) throw const FormatException('fixture failure');
      return true;
    });
    await defaults.seed();
    await defaults.seed();
    expect(urls, [...DefaultSubscriptions.sources.keys, first]);
  });

  test('deleting a default before a successful import prevents reseeding', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final first = DefaultSubscriptions.sources.keys.first;
    await DefaultSubscriptions.rememberRemoved(prefs, first);
    final urls = <String>[];
    await DefaultSubscriptions(prefs, (url, _) async {
      urls.add(url);
      return true;
    }).seed();
    expect(urls, [DefaultSubscriptions.sources.keys.last]);
  });

  test('deduplicates base64 feeds using the connection and keeps the first name', () {
    const a = 'trojan://demo@example.invalid:443?sni=host.invalid&type=tcp#First';
    const b = 'trojan://demo@EXAMPLE.invalid:443?type=tcp&sni=host.invalid#Second';
    const c = 'trojan://other@example.invalid:443?sni=host.invalid&type=tcp#Other';
    expect(deduplicateSubscription(base64Encode(utf8.encode('$a\n$b\n$c'))).split('\n'), [a, c]);
  });
}
