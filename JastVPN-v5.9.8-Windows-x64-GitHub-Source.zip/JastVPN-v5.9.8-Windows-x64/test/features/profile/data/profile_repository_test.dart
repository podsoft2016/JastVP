import 'dart:io';

import 'package:dio/dio.dart';
import 'package:drift/drift.dart' show Value;
import 'package:flutter_test/flutter_test.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hiddify/core/db/db.dart';
import 'package:hiddify/features/profile/data/default_subscriptions.dart';
import 'package:hiddify/features/profile/data/profile_data_mapper.dart';
import 'package:hiddify/features/profile/data/profile_data_source.dart';
import 'package:hiddify/features/profile/data/profile_parser.dart';
import 'package:hiddify/features/profile/data/profile_path_resolver.dart';
import 'package:hiddify/features/profile/data/profile_repository.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/profile/model/profile_failure.dart';
import 'package:hiddify/features/profile/model/profile_sort_enum.dart';
import 'package:hiddify/features/settings/data/config_option_repository.dart';
import 'package:hiddify/hiddifycore/hiddify_core_service.dart';

/// Writes the temp file inside the task, like the real download does.
class _FakeParser implements ProfileParser {
  TaskEither<ProfileFailure, ProfileEntriesCompanion> _download(String tempFilePath) => TaskEither(() async {
    await File(tempFilePath).writeAsString('{}');
    return right(const ProfileEntriesCompanion());
  });

  @override
  TaskEither<ProfileFailure, ProfileEntriesCompanion> addRemote({
    required String id,
    required String url,
    required String tempFilePath,
    required UserOverride? userOverride,
    CancelToken? cancelToken,
  }) => _download(tempFilePath);

  @override
  TaskEither<ProfileFailure, ProfileEntriesCompanion> updateRemote({
    required RemoteProfileEntity rp,
    required String tempFilePath,
    CancelToken? cancelToken,
  }) => _download(tempFilePath);

  @override
  Either<ProfileFailure, ProfileEntriesCompanion> offlineUpdate({
    required ProfileEntity profile,
    required String tempFilePath,
  }) => right(const ProfileEntriesCompanion());

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class _FakeDataSource implements ProfileDataSource {
  _FakeDataSource([this.entry, this.entries = const []]);

  final ProfileEntry? entry;
  final List<ProfileEntry> entries;

  @override
  Stream<List<ProfileEntry>> watchAll({required ProfilesSort sort, required SortMode sortMode}) =>
      Stream.value(entries);

  @override
  Future<ProfileEntry?> getById(String id) async => entry;

  @override
  Future<ProfileEntry?> getByUrl(String url) async => entry;

  @override
  Future<void> insert(ProfileEntriesCompanion entry, {bool activateIfNone = false}) async {
    insertedWithoutChangingActive = activateIfNone;
  }

  bool? insertedWithoutChangingActive;

  /// The edits made, in order.
  final edits = <(String, ProfileEntriesCompanion)>[];

  @override
  Future<void> edit(String id, ProfileEntriesCompanion entry) async => edits.add((id, entry));

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class _UnusedCore implements HiddifyCoreService {
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class _UnusedOptions implements ConfigOptionRepository {
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

/// Stands in for the core check: it records whether the temp file still exists when the config is validated.
class _Repo extends ProfileRepositoryImpl {
  _Repo(ProfileDataSource dataSource, ProfilePathResolver paths, {this.valid = true})
    : super(
        profileDataSource: dataSource,
        profilePathResolver: paths,
        singbox: _UnusedCore(),
        configOptionRepository: _UnusedOptions(),
        profileParser: _FakeParser(),
      );

  final bool valid;
  bool? tempFileSeen;

  @override
  TaskEither<ProfileFailure, Unit> validateConfig(String path, String tempPath, String? profileOverride, bool debug) =>
      TaskEither(() async {
        tempFileSeen = File(tempPath).existsSync();
        if (path.endsWith('.stage.json'))
          await File(path).writeAsString(valid ? '{"outbounds":[{"type":"trojan"}]}' : 'partial');
        return valid ? right(unit) : left(const ProfileFailure.invalidConfig());
      });
}

void main() {
  late Directory root;
  late ProfilePathResolver paths;

  setUp(() async {
    root = await Directory.systemTemp.createTemp('hiddify_profile_test');
    paths = ProfilePathResolver(root);
    await paths.directory.create();
  });

  tearDown(() => root.delete(recursive: true));

  /// The `<id>.tmp.json` files left in the configs folder.
  List<String> leftTempFiles() =>
      paths.directory.listSync().map((f) => f.path).where((path) => path.endsWith('.tmp.json')).toList();

  final remoteEntry = ProfileEntry(
    id: 'remote-id',
    type: ProfileType.remote,
    active: true,
    name: 'remote',
    url: 'https://example.com/sub',
    lastUpdate: DateTime(2026),
    pinned: false,
  );

  group("temp file is deleted after the task", () {
    test("upsertRemote adds a profile", () async {
      final repo = _Repo(_FakeDataSource(), paths);
      final result = await repo.upsertRemote('https://example.com/sub').run();
      expect(result.isRight(), true);
      expect(repo.tempFileSeen, true);
      expect(leftTempFiles(), isEmpty);
    });

    test("upsertRemote fails to add a profile", () async {
      final repo = _Repo(_FakeDataSource(), paths, valid: false);
      final result = await repo.upsertRemote('https://example.com/sub').run();
      expect(result.isLeft(), true);
      expect(repo.tempFileSeen, true);
      expect(leftTempFiles(), isEmpty);
    });

    test("upsertRemote updates a profile", () async {
      final repo = _Repo(_FakeDataSource(remoteEntry), paths);
      final result = await repo.upsertRemote('https://example.com/sub').run();
      expect(result.isRight(), true);
      expect(repo.tempFileSeen, true);
      expect(leftTempFiles(), isEmpty);
    });

    test("offlineUpdate updates a profile", () async {
      final repo = _Repo(_FakeDataSource(remoteEntry), paths);
      final result = await repo.offlineUpdate(remoteEntry.toEntity(), '{}').run();
      expect(result.isRight(), true);
      expect(repo.tempFileSeen, true);
      expect(leftTempFiles(), isEmpty);
    });
  });

  group('default feeds', () {
    final url = DefaultSubscriptions.sources.keys.first;

    test('failed validation cannot replace the last good download', () async {
      final source = _FakeDataSource(remoteEntry.copyWith(url: Value(url)));
      final current = paths.file(remoteEntry.id);
      await current.writeAsString('last good config');
      final result = await _Repo(source, paths, valid: false).upsertRemote(url).run();
      expect(result.isLeft(), isTrue);
      expect(await current.readAsString(), 'last good config');
      expect(await paths.directory.list().length, 1);
      expect(source.edits, isEmpty);
    });

    test('successful refresh replaces the cache without reactivating the profile', () async {
      final source = _FakeDataSource(remoteEntry.copyWith(url: Value(url), active: false));
      final current = paths.file(remoteEntry.id);
      await current.writeAsString('last good config');
      final result = await _Repo(source, paths).upsertRemote(url).run();
      expect(result.isRight(), isTrue);
      expect(await current.readAsString(), '{"outbounds":[{"type":"trojan"}]}');
      expect(source.edits.single.$2.active.present, isFalse);
    });

    test('automatic import requests atomic activation only when no profile is active', () async {
      final source = _FakeDataSource();
      final result = await _Repo(source, paths).upsertRemote(url).run();
      expect(result.isRight(), isTrue);
      expect(source.insertedWithoutChangingActive, isTrue);
    });
  });

  group("adding a profile that is already there", () {
    /// Whether [source] was told to make [id] the active profile.
    bool activated(_FakeDataSource source, String id) =>
        source.edits.any((edit) => edit.$1 == id && edit.$2.active == const Value(true));

    test("selects it", () async {
      final source = _FakeDataSource(remoteEntry.copyWith(active: false));
      final result = await _Repo(source, paths).upsertRemote(remoteEntry.url!, activate: true).run();
      expect(result.isRight(), true);
      expect(activated(source, remoteEntry.id), true);
    });

    test("selects it even when its update fails", () async {
      final source = _FakeDataSource(remoteEntry.copyWith(active: false));
      final result = await _Repo(source, paths, valid: false).upsertRemote(remoteEntry.url!, activate: true).run();
      expect(result.isLeft(), true);
      expect(activated(source, remoteEntry.id), true);
    });

    test("an update does not select it", () async {
      final source = _FakeDataSource(remoteEntry.copyWith(active: false));
      await _Repo(source, paths).upsertRemote(remoteEntry.url!).run();
      expect(activated(source, remoteEntry.id), false);
    });

    test("the active one is left as it is", () async {
      final source = _FakeDataSource(remoteEntry.copyWith(active: true));
      await _Repo(source, paths).upsertRemote(remoteEntry.url!, activate: true).run();
      expect(activated(source, remoteEntry.id), false);
    });
  });

  // hiddify-app#2422: one profile saved with data this version can not read failed the whole list
  test("watchAll lists the profiles saved with data that can not be read", () async {
    final entries = [
      remoteEntry,
      remoteEntry.copyWith(id: 'null-headers', populatedHeaders: const Value('null')),
      remoteEntry.copyWith(id: 'bad-headers', populatedHeaders: const Value('{not json')),
      remoteEntry.copyWith(id: 'bad-choices', userOverride: const Value('{not json')),
      remoteEntry.copyWith(id: 'no-url', url: const Value(null)),
    ];
    final repo = _Repo(_FakeDataSource(null, entries), paths);
    final result = await repo.watchAll().first;
    expect(result.getOrElse((f) => throw f).map((p) => p.id), entries.map((e) => e.id));
  });
}
